import sys
import time
import tkinter as tk

root = tk.Tk()
root.title("Ultron Visible Test")
root.geometry("400x200+500+300")
root.attributes("-topmost", True)
label = tk.Label(root, text="Ultron GUI is Visible!", font=("Segoe UI", 16), fg="#FF5500", bg="#111111")
label.pack(fill="both", expand=True)
root.after(2000, root.destroy)
root.mainloop()
print("Tkinter window displayed and closed cleanly.")
