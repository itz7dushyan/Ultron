Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "C:\ULTRON"
WshShell.Run "pythonw.exe scratch/test_pythonw_show.py", 1, False
Set WshShell = Nothing
