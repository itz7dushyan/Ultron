import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from agents.thinker import thinker_agent

tests = [
    'open Spotify',
    'Spotify band kar do',
    'open Proton VPN',
    'close File Explorer',
    'tab band karo',
    'take a screenshot',
    'organize screenshots',
    'change wallpaper to nature'
]

for t in tests:
    plan = thinker_agent.analyze_and_plan(t, {})
    step = plan["steps"][0]
    print(f"[{t}] -> Action: {step['action']}, Params: {step.get('parameters')} | Spoken: \"{plan['spoken_response']}\"")
