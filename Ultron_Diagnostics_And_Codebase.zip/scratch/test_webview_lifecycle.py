import webview
import threading
import time
import ctypes

def worker(window):
    time.sleep(1.5)
    print("Overlay running cleanly, closing test window...")
    window.destroy()

window = webview.create_window(
    'Ultron HUD',
    html="<body style='background:transparent; color:#ff6600;'><h1>ULTRON</h1></body>",
    transparent=True,
    frameless=True,
    on_top=True,
    width=300,
    height=200
)

t = threading.Thread(target=worker, args=(window,), daemon=True)
t.start()
webview.start()
print("Webview test completed successfully.")
