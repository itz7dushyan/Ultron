import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from agents.thinker import thinker_agent

test_cases = [
    "open google drive in a tab",
    "open drive please",
    "I want you to open Google Drive",
    "Okay, login with Google here",
    "open hosting web",
    "open a chrome tab then we will start doing the SEO work",
    "We are not actually going to target Dubai, we will be targeting Jodhpur only for now. open about us and generate a focus keyword",
    "Can you see what is on the screen?"
]

for cmd in test_cases:
    plan = thinker_agent.analyze_and_plan(cmd, {})
    steps = plan.get("steps", [])
    first_step = steps[0] if steps else {}
    print(f"CMD: '{cmd}'")
    print(f" -> INTENT: {plan.get('intent_summary')}")
    print(f" -> ACTION: {first_step.get('action')} | PARAMS: {first_step.get('parameters')}")
    print(f" -> SPOKEN: {plan.get('spoken_response')}\n")
