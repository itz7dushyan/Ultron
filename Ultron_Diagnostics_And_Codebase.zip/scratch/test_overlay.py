import webview
import time

html = """
<!DOCTYPE html>
<html>
<head>
<style>
  body {
    margin: 0;
    padding: 0;
    overflow: hidden;
    background: transparent;
  }
  .test-box {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 300px;
    height: 100px;
    background: rgba(255, 100, 0, 0.85);
    border-radius: 12px;
    box-shadow: 0 0 30px #ff6600;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: sans-serif;
    font-weight: bold;
    font-size: 20px;
  }
</style>
</head>
<body>
  <div class="test-box">ULTRON HUD TEST</div>
</body>
</html>
"""

def close_after_delay(window):
    time.sleep(2)
    window.destroy()

try:
    window = webview.create_window(
        'Ultron HUD Test',
        html=html,
        transparent=True,
        frameless=True,
        on_top=True,
        width=400,
        height=200
    )
    print("pywebview create_window success")
except Exception as e:
    print(f"pywebview error: {e}")
