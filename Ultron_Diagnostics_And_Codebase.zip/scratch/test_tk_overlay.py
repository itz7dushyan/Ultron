import tkinter as tk
import ctypes
import time
import math

GWL_EXSTYLE = -20
WS_EX_LAYERED = 0x00080000
WS_EX_TRANSPARENT = 0x00000020
WS_EX_TOOLWINDOW = 0x00000080

root = tk.Tk()
root.title("Ultron HUD Overlay")
root.overrideredirect(True)
root.wm_attributes("-topmost", True)
root.wm_attributes("-transparentcolor", "#000001")
root.config(bg="#000001")

screen_w = root.winfo_screenwidth()
screen_h = root.winfo_screenheight()
root.geometry(f"{screen_w}x{screen_h}+0+0")

canvas = tk.Canvas(root, width=screen_w, height=screen_h, bg="#000001", highlightthickness=0)
canvas.pack(fill="both", expand=True)

# Make click-through and toolwindow (no taskbar item)
hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
if hwnd == 0:
    hwnd = root.winfo_id()
style = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
ctypes.windll.user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style | WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW)

print("Tkinter transparent overlay initialized successfully! Screen size:", screen_w, screen_h)
root.after(1000, root.destroy)
root.mainloop()
print("Tkinter overlay test completed.")
